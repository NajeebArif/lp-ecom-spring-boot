package com.cakefactory.service;

import com.cakefactory.model.Item;

import java.util.List;

public interface Catalog {
    List<Item> getItems();
}
