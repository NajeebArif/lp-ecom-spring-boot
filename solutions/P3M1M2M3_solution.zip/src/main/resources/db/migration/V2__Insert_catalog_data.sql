truncate table catalog;
insert into catalog values ('abcr', 'All Butter Croissant', 0.75);
insert into catalog values ('ccr', 'Chocolate Croissant', 0.95);
insert into catalog values ('b', 'Fresh Baguette', 1.60);
insert into catalog values ('rv', 'Red Velvet', 3.95);
insert into catalog values ('vs', 'Victoria Sponge', 5.45);
insert into catalog values ('cc', 'Carrot Cake', 3.45);