package com.cakefactory.model.dto;

public class BasketItem {
}
