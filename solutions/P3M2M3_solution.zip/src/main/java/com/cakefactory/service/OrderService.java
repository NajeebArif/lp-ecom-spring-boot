package com.cakefactory.service;

import com.cakefactory.model.dto.OrderDetailsDto;

public interface OrderService {

    OrderDetailsDto placeOrder();
}
